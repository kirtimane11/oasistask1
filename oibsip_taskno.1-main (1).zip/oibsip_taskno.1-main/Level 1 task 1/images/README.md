oibsip_taskno.1----> Level 1
created a simple landing page for travel-x agency using HTML, CSS.
